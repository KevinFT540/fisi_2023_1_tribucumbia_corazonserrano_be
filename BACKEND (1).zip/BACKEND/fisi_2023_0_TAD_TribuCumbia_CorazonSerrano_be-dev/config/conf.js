require("dotenv").config();

const config = {
    port: '1200',    
    dbUser: 'root',
    dbPassword: 'root',
    dbName: 'hotel_db',
    dbHost: 'localhost',
};

module.exports = { config };
